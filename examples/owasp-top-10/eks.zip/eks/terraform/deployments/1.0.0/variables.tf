variable "environment" {
  description = "Infra environment"
  type        = string
  default     = "dev"
}

variable "aws_region" {
  description = "AWS region to create VPC"
  default     = "us-east-1"
}

variable "tf_bucket" {
  description = "S3 Bucket for remote state"
}

variable "vpc_cidr" {
  description = "CIDR for VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "vpc_id" {
  description = "VPC ID to use for EKS cluster"
  type        = string
  default     = "vpc-0d8c497311a563f29"
}

variable "eks_version" {
  description = "VPC ID to use for EKS cluster"
  type        = string
  default     = "1.31"
}

variable "cluster_name" {
  type        = string
  default     = "dev-eks"
  description = "EKS cluster name"
}

variable "azs" {
  description = "Array AZs. Must match number of public and or private subnets"
  type        = list(any)
}
/*
variable "private_subnets" {
  description = "Array of private subnet CIDR. Must match number of AZs"
  type        = list(any)
}

variable "public_subnets" {
  description = "Array of public subnet CIDR. Must match number of AZs"
  type        = list(any)
}
*/
variable "tags" {
  type        = map(string)
  default     = {}
  description = "Additional tags (e.g. `map('BusinessUnit','XYZ')`"
}
