output "eks" {
  value = module.eks
}

output "eks-addons" {
  value = module.eks_addons
  sensitive = true
}

output "configure_kubectl" {
  description = "Configure kubectl: make sure you're logged in with the correct AWS profile and run the following command to update your kubeconfig"
  value       = "aws eks --region ${local.region} update-kubeconfig --name ${module.eks.cluster_name} --kubeconfig dev-eks.yaml" 
}

output "subnet_names" {
  value = {
    for id, subnet in data.aws_subnet.details :
    id => subnet.tags["Name"]
  }
}
