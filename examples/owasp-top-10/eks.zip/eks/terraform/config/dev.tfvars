vpc_cidr                              = "10.0.0.0/16"
vpc_id                                = "vpc-03420add93af295fa"
azs                                   = ["us-east-1d", "us-east-1b", "us-east-1c"]
aws_region                            = "us-east-1"
environment                           = "dev"
cluster_name                          = "dev-eks"
eks_version                           = "1.31"
